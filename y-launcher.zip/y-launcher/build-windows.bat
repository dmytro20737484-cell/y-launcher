@echo off
echo Installing dependencies...
call npm install || goto :err
echo Building installer...
call npm run dist || goto :err
echo.
echo Done! Installer is in the "dist" folder.
pause
exit /b 0
:err
echo Build failed.
pause
exit /b 1

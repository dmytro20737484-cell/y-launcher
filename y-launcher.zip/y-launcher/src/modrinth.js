const fs = require('fs'), path = require('path');
const AdmZip = require('adm-zip');
const { getJson, download, safeJoin, extractFolder } = require('./util');
const API = 'https://api.modrinth.com/v2';
const H = { 'User-Agent': 'y-launcher/0.1' };

async function search({ query, kind, mc, loader, sort, offset }) {
  const f = [[`project_type:${kind === 'modpack' ? 'modpack' : 'mod'}`]];
  if (mc) f.push([`versions:${mc}`]);
  if (loader && loader !== 'vanilla' && kind !== 'modpack') f.push(loader === 'quilt' ? ['categories:quilt', 'categories:fabric'] : [`categories:${loader}`]);
  const idx = ['relevance', 'downloads', 'newest', 'updated'].includes(sort) ? sort : 'relevance';
  const j = await getJson(`${API}/search?query=${encodeURIComponent(query || '')}&limit=30&offset=${Number(offset) || 0}&index=${idx}&facets=${encodeURIComponent(JSON.stringify(f))}`, { headers: H });
  return { total: j.total_hits, items: j.hits.map(h => ({ id: h.project_id, title: h.title, description: h.description, icon: h.icon_url, downloads: h.downloads })) };
}

async function bestVersion(id, mc, loader) {
  const q = new URLSearchParams();
  if (mc) q.set('game_versions', JSON.stringify([mc]));
  if (loader && loader !== 'vanilla') q.set('loaders', JSON.stringify(loader === 'quilt' ? ['quilt', 'fabric'] : [loader]));
  const v = await getJson(`${API}/project/${id}/version?${q}`, { headers: H });
  return v[0];
}

async function installMod(id, dir, mc, loader, seen = new Set()) {
  if (seen.has(id)) return [];
  seen.add(id);
  const v = await bestVersion(id, mc, loader);
  if (!v) throw new Error('Немає сумісної версії для ' + id);
  const file = v.files.find(f => f.primary) || v.files[0];
  await download(file.url, path.join(dir, 'mods', path.basename(file.filename)), { sha1: file.hashes?.sha1 });
  const done = [file.filename];
  for (const d of v.dependencies || []) {
    if (d.dependency_type === 'required' && d.project_id) {
      try { done.push(...await installMod(d.project_id, dir, mc, loader, seen)); } catch {}
    }
  }
  return done;
}

async function installPack(id, dir, progress = () => {}) {
  const v = await bestVersion(id);
  if (!v) throw new Error('Немає версій модпаку');
  const file = v.files.find(f => f.primary) || v.files[0];
  fs.mkdirSync(dir, { recursive: true });
  const tmp = path.join(dir, 'pack.mrpack');
  await download(file.url, tmp);
  const zip = new AdmZip(tmp);
  const idx = JSON.parse(zip.readAsText('modrinth.index.json'));
  let i = 0;
  for (const f of idx.files) {
    progress(`Моди: ${++i}/${idx.files.length}`);
    if (f.env && f.env.client === 'unsupported') continue;
    await download(f.downloads[0], safeJoin(dir, f.path), { sha1: f.hashes?.sha1 });
  }
  extractFolder(zip, 'overrides', dir);
  extractFolder(zip, 'client-overrides', dir);
  fs.unlinkSync(tmp);
  const d = idx.dependencies;
  const loader = d['fabric-loader'] ? 'fabric' : d['quilt-loader'] ? 'quilt' : d.neoforge ? 'neoforge' : d.forge ? 'forge' : 'vanilla';
  return { mc: d.minecraft, loader, name: idx.name, loaderVersion: d['fabric-loader'] || d['quilt-loader'] || d.neoforge || d.forge || '' };
}

module.exports = { search, installMod, installPack };

const fs = require('fs'), path = require('path'), crypto = require('crypto');

async function getJson(url, opts) {
  const r = await fetch(url, opts);
  if (!r.ok) throw new Error(`HTTP ${r.status} ${url}`);
  return r.json();
}

async function download(url, dest, { headers = {}, sha1, sha256 } = {}) {
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const r = await fetch(url, { headers });
  if (!r.ok) throw new Error(`HTTP ${r.status} ${url}`);
  const buf = Buffer.from(await r.arrayBuffer());
  if (sha1 && crypto.createHash('sha1').update(buf).digest('hex') !== sha1)
    throw new Error('Невірна контрольна сума: ' + url);
  if (sha256 && crypto.createHash('sha256').update(buf).digest('hex') !== String(sha256).toLowerCase())
    throw new Error('Невірна контрольна сума (sha256): ' + url);
  fs.writeFileSync(dest, buf);
  return dest;
}

// захист від zip-slip: шлях не може вийти за межі папки інстансу
function safeJoin(base, rel) {
  const root = path.resolve(base);
  const p = path.resolve(root, rel);
  if (p !== root && !p.startsWith(root + path.sep)) throw new Error('Небезпечний шлях у паку: ' + rel);
  return p;
}

function extractFolder(zip, prefix, dir) {
  for (const e of zip.getEntries()) {
    if (e.isDirectory || !e.entryName.startsWith(prefix + '/')) continue;
    const dest = safeJoin(dir, e.entryName.slice(prefix.length + 1));
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, e.getData());
  }
}

module.exports = { getJson, download, safeJoin, extractFolder };

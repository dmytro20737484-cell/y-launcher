// Встановлення модлоадерів: Fabric, Quilt (через meta-API), Forge і NeoForge (через офіційні інсталятори).
const fs = require('fs'), path = require('path'), { spawn } = require('child_process');
const { getJson, download } = require('./util');

const PROFILES = {
  fabric: { base: 'https://meta.fabricmc.net/v2', prefix: 'fabric', name: 'Fabric', stable: x => x.loader.stable },
  quilt:  { base: 'https://meta.quiltmc.org/v3',  prefix: 'quilt',  name: 'Quilt',  stable: x => !/beta|rc|pre|alpha/i.test(x.loader.version) }
};

function localVersions(root, test) {
  const dir = path.join(root, 'versions');
  if (!fs.existsSync(dir)) return [];
  const out = [];
  for (const id of fs.readdirSync(dir)) {
    const f = path.join(dir, id, id + '.json');
    if (!fs.existsSync(f)) continue;
    try { const j = JSON.parse(fs.readFileSync(f, 'utf8')); if (test(id, j)) out.push(id); } catch {}
  }
  return out.sort();
}

async function fabricLike(root, mc, ver, kind) {
  const P = PROFILES[kind];
  const local = () => localVersions(root, id => id.startsWith(`${P.prefix}-loader-`) && id.endsWith('-' + mc) && (!ver || id === `${P.prefix}-loader-${ver}-${mc}`)).pop();
  let l = ver;
  try {
    if (!l) {
      const list = await getJson(`${P.base}/versions/loader/${mc}`);
      if (!list.length) throw new Error(`${P.name} не підтримує версію ${mc}`);
      l = (list.find(P.stable) || list[0]).loader.version;
    }
    const id = `${P.prefix}-loader-${l}-${mc}`;
    const f = path.join(root, 'versions', id, id + '.json');
    if (!fs.existsSync(f)) {
      const j = await getJson(`${P.base}/versions/loader/${mc}/${l}/profile/json`);
      fs.mkdirSync(path.dirname(f), { recursive: true });
      fs.writeFileSync(f, JSON.stringify(j));
    }
    return id;
  } catch (e) {
    const have = local();           // без інтернету — використовуємо вже встановлений
    if (have) return have;
    throw e;
  }
}

async function mavenVersions(url) {
  const r = await fetch(url);
  if (!r.ok) throw new Error('HTTP ' + r.status + ' ' + url);
  return [...(await r.text()).matchAll(/<version>([^<]+)<\/version>/g)].map(m => m[1]);
}

const isNeo = id => id.toLowerCase().includes('neoforge');
const forgeTest = (kind, mc) => (id, j) => j.inheritsFrom === mc &&
  (kind === 'neoforge' ? isNeo(id) : id.toLowerCase().includes('forge') && !isNeo(id));

function runInstaller(root, jar, flag, log, java) {
  return new Promise((resolve, reject) => {
    const p = spawn(java || 'java', ['-jar', jar, flag, root], { cwd: root, windowsHide: true });
    let tail = '';
    const on = d => { const s = String(d); tail = (tail + s).slice(-2000); s.split(/\r?\n/).filter(Boolean).forEach(log); };
    p.stdout.on('data', on); p.stderr.on('data', on);
    p.on('error', e => reject(new Error(e.code === 'ENOENT' ? 'Java не знайдена. Встановіть Java 17+ і перезапустіть лаунчер' : e.message)));
    p.on('close', c => c === 0 ? resolve() : reject(new Error('Інсталятор завершився з кодом ' + c + '\n' + tail.slice(-500))));
  });
}

// Сучасний Forge/NeoForge використовує плейсхолдери, які кладемо в JSON самі
function fixPlaceholders(root, id) {
  const f = path.join(root, 'versions', id, id + '.json');
  let t = fs.readFileSync(f, 'utf8');
  const libs = JSON.stringify(path.join(root, 'libraries')).slice(1, -1);
  t = t.split('${library_directory}').join(libs).split('${classpath_separator}').join(path.delimiter);
  fs.writeFileSync(f, t);
}

async function forgeLike(root, mc, ver, kind, log, java) {
  const pick = () => localVersions(root, forgeTest(kind, mc)).filter(id => !ver || id.includes(ver)).pop();
  let id = pick();
  if (!id) {
    let url, flag, label;
    if (kind === 'forge') {
      const all = (await mavenVersions('https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml')).filter(v => v.startsWith(mc + '-'));
      const full = ver ? all.find(v => v === `${mc}-${ver}` || v.startsWith(`${mc}-${ver}-`)) : all[all.length - 1];
      if (!full) throw new Error(`Forge для Minecraft ${mc}${ver ? ' ' + ver : ''} не знайдено`);
      url = `https://maven.minecraftforge.net/net/minecraftforge/forge/${full}/forge-${full}-installer.jar`;
      flag = '--installClient'; label = 'Forge ' + full;
    } else {
      const m = mc.match(/^1\.(\d+)(?:\.(\d+))?/);
      const prefix = m ? `${m[1]}.${m[2] || 0}.` : null;
      const all = prefix ? (await mavenVersions('https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml')).filter(v => v.startsWith(prefix)) : [];
      if (!all.length) throw new Error('NeoForge підтримує Minecraft 1.20.2 і новіші (для ' + mc + ' немає збірки)');
      const stable = all.filter(v => !/-(alpha|beta|rc)/i.test(v));
      const full = ver ? all.find(v => v === ver) : (stable.length ? stable : all).pop();
      if (!full) throw new Error('NeoForge ' + ver + ' не знайдено');
      url = `https://maven.neoforged.net/releases/net/neoforged/neoforge/${full}/neoforge-${full}-installer.jar`;
      flag = '--install-client'; label = 'NeoForge ' + full;
    }
    const jar = path.join(root, 'installers', path.basename(url));
    if (!fs.existsSync(jar)) { log('Завантаження інсталятора: ' + label); await download(url, jar); }
    const lp = path.join(root, 'launcher_profiles.json');     // інсталятори вимагають цей файл
    if (!fs.existsSync(lp)) fs.writeFileSync(lp, JSON.stringify({ profiles: {}, version: 3 }));
    log('Встановлення ' + label + ' (це може тривати кілька хвилин)…');
    await runInstaller(root, jar, flag, log, java);
    id = pick();
  }
  if (!id) throw new Error('Інсталятор завершився, але версію ' + kind + ' не знайдено у папці versions');
  fixPlaceholders(root, id);
  return id;
}

// Повертає id версії для version.custom (або undefined для vanilla)
async function ensure(root, mc, loader, ver, log = () => {}, java) {
  if (loader === 'fabric' || loader === 'quilt') return fabricLike(root, mc, ver, loader);
  if (loader === 'forge' || loader === 'neoforge') return forgeLike(root, mc, ver, loader, log, java);
  return undefined;
}

module.exports = { ensure, _test: { localVersions, forgeTest, fixPlaceholders } };

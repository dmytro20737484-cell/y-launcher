const fs = require('fs'), path = require('path');
const AdmZip = require('adm-zip');
const { getJson, download, extractFolder } = require('./util');
const API = 'https://api.curseforge.com/v1';
const LOADER = { forge: 1, fabric: 4, quilt: 5, neoforge: 6 };
const hdr = k => { if (!k) throw new Error('Вкажіть CurseForge API key в налаштуваннях'); return { 'x-api-key': k, Accept: 'application/json' }; };

const fileUrl = f => f.downloadUrl ||
  `https://edge.forgecdn.net/files/${Math.floor(f.id / 1000)}/${f.id % 1000}/${encodeURIComponent(f.fileName)}`;

const SORT = { relevance: 2, downloads: 6, newest: 11, updated: 3 };
async function search(key, { query, kind, mc, loader, sort, offset }) {
  const p = new URLSearchParams({ gameId: 432, classId: kind === 'modpack' ? 4471 : 6,
    searchFilter: query || '', sortField: SORT[sort] || 2, sortOrder: 'desc', pageSize: 30, index: Number(offset) || 0 });
  if (mc) p.set('gameVersion', mc);
  if (kind !== 'modpack' && LOADER[loader]) p.set('modLoaderType', LOADER[loader]);
  const j = await getJson(`${API}/mods/search?${p}`, { headers: hdr(key) });
  return { total: j.pagination?.totalCount ?? j.data.length,
           items: j.data.map(m => ({ id: String(m.id), title: m.name, description: m.summary, icon: m.logo?.thumbnailUrl, downloads: m.downloadCount })) };
}

async function latestFile(key, id, mc, loader) {
  const p = new URLSearchParams({ pageSize: 30 });
  if (mc) p.set('gameVersion', mc);
  if (LOADER[loader]) p.set('modLoaderType', LOADER[loader]);
  const j = await getJson(`${API}/mods/${id}/files?${p}`, { headers: hdr(key) });
  return j.data.sort((a, b) => new Date(b.fileDate) - new Date(a.fileDate))[0];
}

async function installMod(key, id, dir, mc, loader, seen = new Set()) {
  if (seen.has(id)) return [];
  seen.add(id);
  const f = await latestFile(key, id, mc, loader);
  if (!f) throw new Error('Немає сумісної версії для ' + id);
  await download(fileUrl(f), path.join(dir, 'mods', path.basename(f.fileName)));
  const done = [f.fileName];
  for (const d of f.dependencies || []) {
    if (d.relationType === 3) { try { done.push(...await installMod(key, String(d.modId), dir, mc, loader, seen)); } catch {} }
  }
  return done;
}

async function installPack(key, id, dir, progress = () => {}) {
  const f = await latestFile(key, id);
  fs.mkdirSync(dir, { recursive: true });
  const tmp = path.join(dir, 'pack.zip');
  await download(fileUrl(f), tmp);
  const zip = new AdmZip(tmp);
  const man = JSON.parse(zip.readAsText('manifest.json'));
  const ids = man.files.map(x => x.fileID);
  const r = await fetch(`${API}/mods/files`, { method: 'POST', headers: { ...hdr(key), 'Content-Type': 'application/json' }, body: JSON.stringify({ fileIds: ids }) });
  if (!r.ok) throw new Error('CurseForge HTTP ' + r.status);
  const files = (await r.json()).data;
  let i = 0;
  for (const x of files) {
    progress(`Моди: ${++i}/${files.length}`);
    await download(fileUrl(x), path.join(dir, 'mods', path.basename(x.fileName)));
  }
  extractFolder(zip, man.overrides || 'overrides', dir);
  fs.unlinkSync(tmp);
  const ml = (man.minecraft.modLoaders.find(m => m.primary) || man.minecraft.modLoaders[0])?.id || 'vanilla';
  const loader = ml.split('-')[0];
  return { mc: man.minecraft.version, loader, name: man.name, loaderVersion: ml.slice(loader.length + 1) };
}

module.exports = { search, installMod, installPack };

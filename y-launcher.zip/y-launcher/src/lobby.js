const WebSocket = require('ws');
const { EventEmitter } = require('events');
// Протокол сесій Ely.by (authlib-injector): клієнт "заходить" на сервер з challenge,
// а лобі-сервер перевіряє це через hasJoined — так доводиться, що ти справжній власник ніка.
const JOIN = 'https://authserver.ely.by/api/authlib-injector/sessionserver/session/minecraft/join';

class Lobby extends EventEmitter {
  constructor(url, auth) { super(); this.url = url; this.auth = auth; }
  connect() {
    this.ws = new WebSocket(this.url);
    this.ws.on('message', async raw => {
      let m; try { m = JSON.parse(raw); } catch { return; }
      if (m.t === 'challenge') {
        try {
          const r = await fetch(JOIN, { method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accessToken: this.auth.accessToken, selectedProfile: this.auth.uuid, serverId: m.serverId }) });
          if (!r.ok) throw new Error('Ely.by session join ' + r.status);
          this.send({ t: 'auth', name: this.auth.name });
        } catch (e) { this.emit('event', { t: 'error', message: e.message }); }
      } else this.emit('event', m);
    });
    this.ws.on('close', () => this.emit('event', { t: 'closed' }));
    this.ws.on('error', e => this.emit('event', { t: 'error', message: e.message }));
  }
  send(m) { if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(m)); }
  close() { this.ws && this.ws.close(); }
}
module.exports = { Lobby };

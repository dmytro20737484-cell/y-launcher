const fs = require('fs'), path = require('path'), crypto = require('crypto');
const { getJson, download } = require('./util');
const AUTH = 'https://authserver.ely.by/auth';

async function post(p, body) {
  let r;
  try {
    r = await fetch(AUTH + p, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body), signal: AbortSignal.timeout(20000)
    });
  } catch (e) {
    const why = e.name === 'TimeoutError' ? 'таймаут 20 с' : (e.cause && (e.cause.code || e.cause.message)) || e.message;
    throw new Error('Немає зв\'язку з Ely.by (' + why + ')');
  }
  const t = await r.text();
  let j = {}; try { j = t ? JSON.parse(t) : {}; } catch {}
  if (!r.ok) throw new Error(j.errorMessage || j.message || j.error || `Ely.by помилка ${r.status}`);
  return j;
}

// Якщо в акаунті увімкнена 2FA — пароль передається як "пароль:код"
async function login(username, password, totp) {
  const j = await post('/authenticate', {
    username, password: totp ? `${password}:${totp}` : password,
    clientToken: crypto.randomUUID(), requestUser: true
  });
  return { accessToken: j.accessToken, clientToken: j.clientToken,
           uuid: j.selectedProfile.id, name: j.selectedProfile.name };
}

async function refresh(a) {
  const j = await post('/refresh', { accessToken: a.accessToken, clientToken: a.clientToken });
  return { ...a, accessToken: j.accessToken, uuid: j.selectedProfile?.id || a.uuid, name: j.selectedProfile?.name || a.name };
}

// authlib-injector — підміняє сервери авторизації Mojang на Ely.by (скіни, мультиплеєр)
async function ensureAuthlib(root) {
  const jar = path.join(root, 'authlib-injector.jar');
  if (fs.existsSync(jar)) return jar;
  const info = await getJson('https://authlib-injector.yushi.moe/artifact/latest.json');
  await download(info.download_url, jar);
  return jar;
}

async function invalidate(a) {
  try { await post('/invalidate', { accessToken: a.accessToken, clientToken: a.clientToken }); } catch {}
}

module.exports = { login, refresh, invalidate, ensureAuthlib };

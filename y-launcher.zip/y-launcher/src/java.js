const { spawn } = require('child_process');
const fs = require('fs'), path = require('path'), os = require('os');
const AdmZip = require('adm-zip');
const { getJson, download } = require('./util');

// "1.8.0_51" -> 8, "17.0.9" -> 17, "21" -> 21
const parseMajor = out => {
  const m = /version "(\d+)(?:\.(\d+))?/.exec(out);
  if (!m) return 0;
  return m[1] === '1' ? Number(m[2]) : Number(m[1]);
};

// мінімальна Java для версії Minecraft
function requiredJava(mc) {
  const y = /^(\d+)\./.exec(mc);
  if (y && +y[1] >= 26) return 25;          // нова нумерація версій (26.x), наскільки мені відомо
  const m = /^1\.(\d+)(?:\.(\d+))?/.exec(mc);
  if (!m) return 17;
  const a = +m[1], b = +(m[2] || 0);
  if (a <= 16) return 8;
  if (a === 17) return 16;
  if (a < 20 || (a === 20 && b < 5)) return 17;
  return 21;
}

function javaInfo(bin) {
  return new Promise((resolve, reject) => {
    let out = '';
    const p = spawn(bin || 'java', ['-version'], { windowsHide: true });
    p.stdout.on('data', d => out += d);
    p.stderr.on('data', d => out += d);
    p.on('error', e => reject(new Error(e.code === 'ENOENT'
      ? 'Java не знайдена. Встановіть Java 17+ (adoptium.net) або вкажіть шлях до java.exe в Налаштуваннях'
      : e.message)));
    p.on('close', () => resolve({ major: parseMajor(out), raw: out.split(/\r?\n/)[0] }));
  });
}

// Шукає встановлені Java: типові папки Windows, JAVA_HOME і PATH
function candidates() {
  const win = process.platform === 'win32', exe = win ? 'java.exe' : 'java', out = new Set();
  const vendors = ['Eclipse Adoptium', 'Java', 'Microsoft', 'Zulu', 'BellSoft', 'Amazon Corretto', 'Semeru', 'AdoptOpenJDK', 'Eclipse Foundation', 'OpenJDK', 'Temurin'];
  const roots = [];
  for (const e of ['ProgramFiles', 'ProgramFiles(x86)', 'LOCALAPPDATA']) if (process.env[e]) vendors.forEach(v => roots.push(path.join(process.env[e], v)));
  roots.push(path.join(os.homedir(), '.jdks'));
  for (const r of roots) {
    let list; try { list = fs.readdirSync(r); } catch { continue; }
    for (const d of list) { const p = path.join(r, d, 'bin', exe); if (fs.existsSync(p)) out.add(p); }
  }
  if (process.env.JAVA_HOME) out.add(path.join(process.env.JAVA_HOME, 'bin', exe));
  out.add('java');
  return [...out];
}

const LTS = [8, 11, 17, 21, 25];
const managedDir = root => path.join(root, 'java');

// Java, які лаунчер завантажив сам: <root>/java/<версія>/<папка>/bin/java.exe
function managedExes(root) {
  const out = [], exe = process.platform === 'win32' ? 'java.exe' : 'java';
  try {
    for (const m of fs.readdirSync(managedDir(root)))
      for (const d of fs.readdirSync(path.join(managedDir(root), m))) {
        const p = path.join(managedDir(root), m, d, 'bin', exe);
        if (fs.existsSync(p)) out.push(p);
      }
  } catch {}
  return out;
}

async function findJavas(root) {
  const res = [];
  for (const c of [...candidates(), ...(root ? managedExes(root) : [])]) {
    try { const i = await javaInfo(c); if (i.major) res.push({ path: c, ...i }); } catch {}
  }
  return res;
}

// найближча за версією підходяща Java (напр. для 17 — спершу 17, потім 21)
function choose(all, need) {
  return all.filter(j => j.major >= need).sort((a, b) => a.major - b.major)[0];
}

// Завантаження JRE з Adoptium (Temurin) з перевіркою sha256
async function downloadJava(root, major, onProgress = () => {}) {
  if (process.platform !== 'win32') throw new Error('Автозавантаження Java працює лише у Windows');
  const arch = process.arch === 'arm64' ? 'aarch64' : 'x64';
  onProgress(`Пошук Java ${major}…`);
  const info = await getJson(`https://api.adoptium.net/v3/assets/latest/${major}/hotspot?architecture=${arch}&image_type=jre&os=windows`);
  const pkg = info && info[0] && info[0].binary && info[0].binary.package;
  if (!pkg) throw new Error(`Adoptium не має Java ${major} для цієї системи`);
  const dir = path.join(managedDir(root), String(major));
  fs.mkdirSync(dir, { recursive: true });
  const zip = path.join(dir, 'jre.zip');
  onProgress(`Завантаження Java ${major} (${Math.round((pkg.size || 0) / 1048576)} МБ)…`);
  await download(pkg.link, zip, { sha256: pkg.checksum });
  onProgress('Розпакування Java…');
  new AdmZip(zip).extractAllTo(dir, true);
  fs.unlinkSync(zip);
  const p = managedExes(root).find(x => x.startsWith(dir + path.sep));
  if (!p) throw new Error('Не вдалося розпакувати Java ' + major);
  return p;
}

async function pickJava(need, override, { root, auto = true, onProgress = () => {} } = {}) {
  if (override) {
    const i = await javaInfo(override);
    if (i.major < need) throw new Error(`Вказана Java має версію ${i.major}, а потрібна ${need}+. Змініть шлях у Налаштуваннях або очистіть поле для автовибору`);
    return { path: override, ...i };
  }
  const all = await findJavas(root);
  const best = choose(all, need);
  if (best) return best;
  if (auto && root) {
    const major = LTS.find(v => v >= need) || need;
    const p = await downloadJava(root, major, onProgress);
    const i = await javaInfo(p);
    if (i.major >= need) return { path: p, ...i };
  }
  const have = [...new Set(all.map(j => j.major))].join(', ');
  throw new Error(`Потрібна Java ${need}+${have ? ' (знайдено: Java ' + have + ')' : ', але Java не знайдено'}. Встановіть її з adoptium.net або увімкніть автозавантаження в Налаштуваннях`);
}

module.exports = { javaInfo, requiredJava, parseMajor, findJavas, choose, pickJava, downloadJava };

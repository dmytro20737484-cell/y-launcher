const { app, BrowserWindow, ipcMain, shell } = require('electron');
require('dns').setDefaultResultOrder('ipv4first');
const path = require('path'), fs = require('fs'), crypto = require('crypto');
const { Client } = require('minecraft-launcher-core');
const ely = require('./src/ely'), mr = require('./src/modrinth'), cf = require('./src/curseforge');
const { pickJava, requiredJava } = require('./src/java');
const loaders = require('./src/loaders'), { Lobby } = require('./src/lobby'), { getJson } = require('./src/util');

let win, lobby, store;
const DATA = () => app.getPath('userData');
const ROOT = () => path.join(DATA(), 'minecraft');       // спільні assets/libraries/versions
const INST = () => path.join(DATA(), 'instances');       // окрема папка на кожну збірку
const STORE = () => path.join(DATA(), 'store.json');
const send = (ch, d) => win && !win.isDestroyed() && win.webContents.send(ch, d);

function load() {
  try { store = JSON.parse(fs.readFileSync(STORE(), 'utf8')); } catch { store = {}; }
  store.settings = { curseforgeKey: '', lobbyUrl: 'ws://localhost:8787', memory: '4G', javaPath: '', sounds: true, autoJava: true, ...store.settings };
}
const save = () => fs.writeFileSync(STORE(), JSON.stringify(store, null, 2), { mode: 0o600 });
const instDir = n => {
  n = String(n || '');
  if (!/^[\p{L}\p{N} ._-]{1,60}$/u.test(n) || n.includes('..') || /[. ]$/.test(n) || n.startsWith('.'))
    throw new Error('Некоректна назва збірки (літери, цифри, пробіл, . _ -)');
  return path.join(INST(), n);
};
const readInst = n => JSON.parse(fs.readFileSync(path.join(instDir(n), 'instance.json'), 'utf8'));
const writeInst = (n, d) => { fs.mkdirSync(instDir(n), { recursive: true }); fs.writeFileSync(path.join(instDir(n), 'instance.json'), JSON.stringify(d)); };
const profile = a => a && { name: a.name, uuid: a.uuid, offline: !!a.offline };
// UUID офлайн-гравця — як у ванільного Minecraft: md5("OfflinePlayer:<нік>"), версія 3
function offlineUuid(name) {
  const h = crypto.createHash('md5').update('OfflinePlayer:' + name).digest();
  h[6] = (h[6] & 0x0f) | 0x30; h[8] = (h[8] & 0x3f) | 0x80;
  return h.toString('hex');
}

app.whenReady().then(() => {
  load();
  win = new BrowserWindow({ width: 1000, height: 680, backgroundColor: '#14161a',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true } });
  win.setMenuBarVisibility(false);
  win.webContents.on('before-input-event', (e, i) => {
    if (i.type === 'keyDown' && (i.key === 'F12' || (i.control && i.shift && String(i.key).toLowerCase() === 'i'))) win.webContents.toggleDevTools();
  });
  win.loadFile('renderer/index.html');
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
});
app.on('window-all-closed', () => app.quit());

ipcMain.handle('app:version', () => app.getVersion());

// ---------- Ely.by ----------
ipcMain.handle('auth:login', async (_e, { username, password, totp }) => {
  store.auth = await ely.login(username, password, totp); save(); return profile(store.auth);
});
ipcMain.handle('auth:offline', (_e, { name }) => {
  if (!/^[A-Za-z0-9_]{3,16}$/.test(name || '')) throw new Error('Нік: 3–16 символів, латиниця, цифри або _');
  store.auth = { offline: true, name, uuid: offlineUuid(name), accessToken: 'offline', clientToken: 'offline' };
  save(); return profile(store.auth);
});
ipcMain.handle('auth:restore', async () => {
  if (!store.auth) return null;
  if (store.auth.offline) return profile(store.auth);
  try { store.auth = await ely.refresh(store.auth); save(); return profile(store.auth); }
  catch { store.auth = null; save(); return null; }
});
ipcMain.handle('auth:logout', async () => {
  if (store.auth && !store.auth.offline) await ely.invalidate(store.auth);
  store.auth = null; save(); if (lobby) lobby.close();
});

// ---------- налаштування / версії / збірки ----------
ipcMain.handle('settings:get', () => store.settings);
ipcMain.handle('settings:set', (_e, s) => { store.settings = { ...store.settings, ...s }; save(); });
ipcMain.handle('versions:list', async () => {
  const m = await getJson('https://launchermeta.mojang.com/mc/game/version_manifest_v2.json');
  return m.versions.filter(v => v.type === 'release').map(v => v.id);
});
ipcMain.handle('instances:list', () => {
  fs.mkdirSync(INST(), { recursive: true });
  return fs.readdirSync(INST()).flatMap(n => { try { return [{ name: n, ...readInst(n) }]; } catch { return []; } });
});
ipcMain.handle('instances:create', (_e, { name, mc, loader }) => {
  if (fs.existsSync(instDir(name))) throw new Error('Збірка з такою назвою вже існує');
  writeInst(name, { mc, loader });
});
ipcMain.handle('instances:update', (_e, { name, ram, jvm }) => {
  if (ram && !/^\d{1,2}[MG]$/i.test(ram)) throw new Error("Пам'ять: наприклад 4G або 2048M");
  const d = readInst(name);
  d.ram = ram || ''; d.jvm = String(jvm || '').trim().slice(0, 500);
  writeInst(name, d);
});
ipcMain.handle('instances:rename', (_e, { name, to }) => {
  const a = instDir(name), b = instDir(to);
  if (fs.existsSync(b)) throw new Error('Збірка з такою назвою вже існує');
  fs.renameSync(a, b);
});
ipcMain.handle('instances:duplicate', (_e, { name, to }) => {
  const a = instDir(name), b = instDir(to);
  if (fs.existsSync(b)) throw new Error('Збірка з такою назвою вже існує');
  fs.cpSync(a, b, { recursive: true });
});
ipcMain.handle('instances:delete', (_e, { name }) => { fs.rmSync(instDir(name), { recursive: true, force: true }); });
ipcMain.handle('instances:openFolder', (_e, { name }) => shell.openPath(instDir(name)));

// ---------- моди та модпаки ----------
ipcMain.handle('mods:search', (_e, a) =>
  a.source === 'modrinth' ? mr.search(a) : cf.search(store.settings.curseforgeKey, a));

ipcMain.handle('mods:install', async (_e, { source, id, kind, instance, title }) => {
  const prog = m => send('progress', m);
  if (kind === 'modpack') {
    const name = (title || 'modpack').replace(/[^\w .-]/g, '').trim().slice(0, 60) || 'modpack';
    const dir = instDir(name);
    const r = source === 'modrinth' ? await mr.installPack(id, dir, prog)
                                     : await cf.installPack(store.settings.curseforgeKey, id, dir, prog);
    writeInst(name, { mc: r.mc, loader: r.loader, loaderVersion: r.loaderVersion || '' });
    return `Модпак встановлено як «${name}» (${r.mc}, ${r.loader})`;
  }
  const inst = readInst(instance), dir = instDir(instance);
  const done = source === 'modrinth' ? await mr.installMod(id, dir, inst.mc, inst.loader)
                                      : await cf.installMod(store.settings.curseforgeKey, id, dir, inst.mc, inst.loader);
  return `Встановлено: ${done.join(', ')}`;
});

// ---------- встановлені моди ----------
const modsDir = n => { const d = path.join(instDir(n), 'mods'); fs.mkdirSync(d, { recursive: true }); return d; };
const modFile = f => { const b = path.basename(String(f)); if (b !== f || !/\.jar(\.disabled)?$/i.test(b)) throw new Error('Некоректний файл'); return b; };
ipcMain.handle('mods:installed', (_e, { instance }) => {
  const d = modsDir(instance);
  return fs.readdirSync(d).filter(f => /\.jar(\.disabled)?$/i.test(f)).map(f => ({
    file: f, name: f.replace(/\.disabled$/i, ''), enabled: !/\.disabled$/i.test(f), size: fs.statSync(path.join(d, f)).size
  })).sort((a, b) => a.name.localeCompare(b.name));
});
ipcMain.handle('mods:toggle', (_e, { instance, file }) => {
  const d = modsDir(instance), f = modFile(file);
  fs.renameSync(path.join(d, f), path.join(d, /\.disabled$/i.test(f) ? f.replace(/\.disabled$/i, '') : f + '.disabled'));
});
ipcMain.handle('mods:remove', (_e, { instance, file }) => { fs.unlinkSync(path.join(modsDir(instance), modFile(file))); });
ipcMain.handle('mods:openFolder', (_e, { instance }) => shell.openPath(modsDir(instance)));

// ---------- запуск гри ----------
ipcMain.handle('game:launch', async (_e, { instance, server }) => {
  const a = store.auth; if (!a) throw new Error('Увійдіть через Ely.by');
  const inst = readInst(instance);
  if (!['vanilla', 'fabric', 'quilt', 'forge', 'neoforge'].includes(inst.loader)) throw new Error(`Завантажувач ${inst.loader} не підтримується`);
  const need = requiredJava(inst.mc);
  const java = await pickJava(need, store.settings.javaPath, { root: DATA(), auto: store.settings.autoJava !== false, onProgress: m => { send('progress', m); send('game:log', m); } });
  send('game:log', `Java: ${java.raw} (${java.path})`);
  fs.mkdirSync(ROOT(), { recursive: true });
  const jar = a.offline ? null : await ely.ensureAuthlib(ROOT());
  const version = { number: inst.mc, type: 'release' };
  if (inst.loader !== 'vanilla') {
    send('progress', 'Підготовка ' + inst.loader + '…');
    version.custom = await loaders.ensure(ROOT(), inst.mc, inst.loader, inst.loaderVersion, m => { send('game:log', m); send('progress', String(m).slice(0, 120)); }, java.path);
  }

  const opts = {
    authorization: { access_token: a.accessToken, client_token: a.clientToken, uuid: a.uuid, name: a.name,
                     user_properties: '{}', meta: { type: 'mojang', demo: false } },
    root: ROOT(), version,
    memory: { max: inst.ram || store.settings.memory, min: '1G' },
    overrides: { gameDirectory: instDir(instance) },
    customArgs: [...(jar ? [`-javaagent:${jar}=ely.by`] : []), ...String(inst.jvm || '').split(/\s+/).filter(Boolean)]
  };
  opts.javaPath = java.path;
  if (server && server.host) opts.server = { host: server.host, port: String(server.port || 25565) };

  const l = new Client();
  l.on('progress', p => send('progress', `Завантаження ${p.type}: ${p.task}/${p.total}`));
  const mask = s => String(s).replace(/(--(?:accessToken|xuid)\s+)\S+/g, '$1***');   // не світимо токен у журналі
  l.on('debug', m => send('game:log', mask(m)));
  l.on('data', m => send('game:log', mask(m)));
  l.on('close', c => send('game:closed', c));
  const proc = await l.launch(opts);
  if (!proc) throw new Error('Не вдалося запустити гру (перевірте, що встановлена Java)');
});

// ---------- лобі ----------
ipcMain.handle('lobby:connect', () => {
  if (!store.auth) throw new Error('Увійдіть через Ely.by');
  if (store.auth.offline) throw new Error('Лобі працює лише з акаунтом Ely.by');
  if (lobby) lobby.close();
  lobby = new Lobby(store.settings.lobbyUrl, store.auth);
  lobby.on('event', e => send('lobby:event', e));
  lobby.connect();
});
ipcMain.handle('lobby:send', (_e, m) => lobby && lobby.send(m));

# Y Launcher

Лаунчер без реклами: вхід через Ely.by, моди/модпаки з Modrinth і CurseForge, лобі для друзів.

## Запуск
    npm install
    npm start            # лаунчер (потрібна Java в PATH)
    npm run lobby        # лобі-сервер (на VPS або локально, порт 8787)
    npm run dist         # збірка інсталятора

## Налаштування
- CurseForge: отримайте API key на console.curseforge.com і вставте в Налаштування.
- Лобі: вкажіть ws://адреса:8787 (для друзів — публічний хост; для TLS поставте за nginx і використовуйте wss://).
- Друзі заходять у світ за адресою, яку вказує власник лобі (dedicated-сервер, або тунель типу playit.gg для світу «Відкрити для мережі»).

## Підтримується
vanilla, Fabric, Quilt, Forge і NeoForge. Для Forge/NeoForge потрібна Java 17+ (інсталятор запускається автоматично).

## Інсталер для Windows
- На Windows: двічі клікніть `build-windows.bat` → готовий `Y-Launcher-Setup-*.exe` у папці `dist`.
- Без Windows: залийте проєкт на GitHub і запустіть workflow «Build Windows installer» (Actions) — .exe буде в артефактах.

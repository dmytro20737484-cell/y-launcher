(() => {
'use strict';
const $ = s => document.querySelector(s), api = window.api;
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const status = t => $('#status').textContent = t;
const fail = m => { sfx.play('error'); status(m); };
let results = [], lobby = null, instances = [];

function opts(sel, arr) { sel.innerHTML = arr.map(v => `<option>${esc(v)}</option>`).join(''); }

async function showApp(me) {
  $('#login').hidden = true; $('#app').hidden = false; $('#me').textContent = me.name; $('#acctType').textContent = me.offline ? 'Офлайн' : 'Ely.by'; $('#avatar').textContent = me.name[0].toUpperCase();
  opts($('#newVer'), await api.invoke('versions:list').catch(() => ['1.20.1']));
  await loadInstances();
  const s = await api.invoke('settings:get');
  $('#cfKey').value = s.curseforgeKey; $('#sndOn').checked = s.sounds !== false; sfx.enabled = s.sounds !== false; $('#lobbyUrl').value = s.lobbyUrl; $('#mem').value = s.memory; $('#javaPath').value = s.javaPath || ''; $('#autoJava').checked = s.autoJava !== false;
}
async function loadInstances() {
  const list = await api.invoke('instances:list');
  instances = list;
  const html = list.map(i => `<option value="${esc(i.name)}">${esc(i.name)} (${esc(i.mc)}, ${esc(i.loader)})</option>`).join('');
  const keep = [$('#inst').value, $('#instMods').value];
  $('#inst').innerHTML = html; $('#instMods').innerHTML = html;
  const setIf = (sel, v) => { if ([...sel.options].some(o => o.value === v)) sel.value = v; };
  setIf($('#inst'), keep[0]); setIf($('#instMods'), keep[1]); fillMgr();
}
const err = e => String(e.message || e).replace(/^Error invoking remote method '[^']+': (Error: )?/, '');

(async () => { const me = await api.invoke('auth:restore'); if (me) showApp(me); })();

$('#loginBtn').onclick = async () => {
  const btn = $('#loginBtn'); $('#loginErr').textContent = ''; btn.disabled = true; btn.textContent = 'Входжу…';
  try {
    const me = await api.invoke('auth:login', { username: $('#u').value.trim(), password: $('#p').value, totp: $('#totp').value.trim() });
    await showApp(me); sfx.play('success');
  } catch (e) {
    const m = err(e); $('#loginErr').textContent = m; sfx.play('error');
    if (/two.?factor|2fa|totp|token/i.test(m)) $('#totp').hidden = false;
  }
  btn.disabled = false; btn.textContent = 'Увійти';
};
window.addEventListener('unhandledrejection', e => { $('#loginErr').textContent = err(e.reason); fail(err(e.reason)); });
$('#logout').onclick = async () => { await api.invoke('auth:logout'); location.reload(); };

document.querySelectorAll('nav [data-tab]').forEach(b => b.onclick = () => {
  document.querySelectorAll('.tab').forEach(t => t.hidden = t.id !== b.dataset.tab);
  document.querySelectorAll('nav [data-tab]').forEach(x => x.classList.toggle('on', x === b));
});

// ----- гра -----
$('#createInst').onclick = async () => {
  try { await api.invoke('instances:create', { name: $('#newName').value, mc: $('#newVer').value, loader: $('#newLoader').value }); await loadInstances(); }
  catch (e) { fail(err(e)); }
};
async function play(server) {
  $('#log').textContent = '';
  try { await api.invoke('game:launch', { instance: $('#inst').value, server }); status('Гру запущено'); sfx.play('launch'); }
  catch (e) { fail(err(e)); }
}
$('#playBtn').onclick = () => play();
api.on('game:log', m => { const l = $('#log'); l.textContent += m + '\n'; l.scrollTop = l.scrollHeight; });
api.on('game:closed', c => status('Гру закрито (код ' + c + ')'));
api.on('progress', m => status(m));

// ----- моди -----
let page = { offset: 0, total: 0, args: null }, installed = [];
const cardHtml = (r, i) => `<div class="card">${r.icon ? `<img src="${esc(r.icon)}">` : ''}
  <div><b>${esc(r.title)}</b><br><span class="muted">${esc(r.description)}</span><br><small class="muted">⬇ ${Number(r.downloads || 0).toLocaleString('uk')}</small></div>
  <button data-i="${i}">Встановити</button></div>`;

async function runSearch(append) {
  if (!append) { results = []; page = { offset: 0, total: 0, args: null }; $('#results').innerHTML = ''; }
  const kind = $('#kind').value, inst = $('#instMods').selectedOptions[0]?.textContent || '';
  const m = inst.match(/\(([^,]+), (\w+)\)/);
  const args = page.args || { source: $('#src').value, kind, query: $('#q').value, sort: $('#sort').value,
                              mc: kind === 'mod' && m ? m[1] : '', loader: m ? m[2] : '' };
  page.args = args; status('Пошук…');
  try {
    const r = await api.invoke('mods:search', { ...args, offset: page.offset });
    const start = results.length;
    results = results.concat(r.items);
    $('#results').insertAdjacentHTML('beforeend', r.items.map((x, k) => cardHtml(x, start + k)).join(''));
    page.offset += r.items.length; page.total = r.total;
    $('#more').hidden = !r.items.length || page.offset >= r.total;
    $('#count').textContent = results.length ? `Показано ${results.length} з ${r.total}` : 'Нічого не знайдено';
    status('Готово');
  } catch (e) { fail(err(e)); }
}
$('#searchBtn').onclick = () => runSearch(false);
$('#more').onclick = () => runSearch(true);
$('#q').addEventListener('keydown', e => { if (e.key === 'Enter') runSearch(false); });
document.querySelector('[data-tab=browse]').addEventListener('click', () => { if (!page.args) runSearch(false); });

$('#results').onclick = async e => {
  const b = e.target.closest('button[data-i]'); if (!b) return;
  const r = results[b.dataset.i], a = page.args; b.disabled = true; status('Встановлення…');
  try {
    status(await api.invoke('mods:install', { source: a.source, id: r.id, kind: a.kind, instance: $('#instMods').value, title: r.title }));
    sfx.play('success'); await loadInstances();
  } catch (e2) { fail(err(e2)); }
  b.disabled = false;
};

// встановлені моди
async function loadInstalled() {
  const inst = $('#instMods').value;
  if (!inst) { $('#instList').innerHTML = '<p class="muted">Спершу створіть збірку</p>'; return; }
  try { installed = await api.invoke('mods:installed', { instance: inst }); } catch (e) { return fail(err(e)); }
  $('#instList').innerHTML = installed.length ? installed.map((f, i) => `<div class="card">
    <div><b>${esc(f.name)}</b><br><span class="muted">${(f.size / 1048576).toFixed(2)} МБ${f.enabled ? '' : ' · вимкнено'}</span></div>
    <label class="switch tight" title="Увімкнено"><input type="checkbox" data-t="${i}" ${f.enabled ? 'checked' : ''}></label>
    <button data-d="${i}">Видалити</button></div>`).join('') : '<p class="muted">У цій збірці ще немає модів</p>';
  status(`Встановлено модів: ${installed.length}`);
}
document.querySelectorAll('[data-sub]').forEach(b => b.onclick = () => {
  document.querySelectorAll('[data-sub]').forEach(x => x.classList.toggle('on', x === b));
  const inst = b.dataset.sub === 'installed';
  $('#catalog').hidden = inst; $('#installedBox').hidden = !inst;
  if (inst) loadInstalled();
});
$('#instMods').onchange = () => { if (!$('#installedBox').hidden) loadInstalled(); };
$('#instList').onchange = async e => {
  const t = e.target.dataset.t; if (t === undefined) return;
  try { await api.invoke('mods:toggle', { instance: $('#instMods').value, file: installed[t].file }); } catch (x) { fail(err(x)); }
  loadInstalled();
};
$('#instList').onclick = async e => {
  const d = e.target.closest('button[data-d]'); if (!d) return;
  const f = installed[d.dataset.d];
  if (!confirm('Видалити ' + f.name + '?')) return;
  try { await api.invoke('mods:remove', { instance: $('#instMods').value, file: f.file }); } catch (x) { fail(err(x)); }
  loadInstalled();
};
$('#openMods').onclick = () => { const i = $('#instMods').value; if (i) api.invoke('mods:openFolder', { instance: i }); };

// ----- лобі -----
const send = m => api.invoke('lobby:send', m);
$('#lobbyConnect').onclick = () => api.invoke('lobby:connect').catch(e => $('#lobbyErr').textContent = err(e));
$('#lobbyCreate').onclick = () => send({ t: 'create', address: $('#lobbyAddr').value.trim() });
$('#lobbyJoin').onclick = () => send({ t: 'join', code: $('#lobbyCode').value.trim() });
$('#invBtn').onclick = () => { send({ t: 'invite', to: $('#invName').value.trim() }); $('#invName').value = ''; };
$('#lobbyLeave').onclick = () => send({ t: 'leave' });
$('#lobbyPlay').onclick = () => {
  if (!lobby || !lobby.address) return $('#lobbyErr').textContent = 'Власник ще не вказав адресу';
  const [host, port] = lobby.address.split(':'); play({ host, port: port || 25565 });
};
api.on('lobby:event', m => {
  $('#lobbyErr').textContent = '';
  if (m.t === 'ready') { $('#lobbyStatus').textContent = 'підключено як ' + m.name; sfx.play('success'); }
  else if (m.t === 'closed') $('#lobbyStatus').textContent = 'відключено';
  else if (m.t === 'error') { $('#lobbyErr').textContent = m.message; sfx.play('error'); }
  else if (m.t === 'left') { lobby = null; $('#lobbyBox').hidden = true; }
  else if (m.t === 'lobby') {
    lobby = m; $('#lobbyBox').hidden = false;
    $('#lc').textContent = m.code; $('#lh').textContent = m.host; $('#la').textContent = m.address || '—';
    $('#lm').innerHTML = m.members.map(n => `<li>${esc(n)}</li>`).join('');
  } else if (m.t === 'invite') {
    const d = document.createElement('div'); d.className = 'card';
    d.innerHTML = `<div><b>${esc(m.from)}</b> запрошує вас у лобі ${esc(m.code)}</div><button>Приєднатись</button>`;
    d.querySelector('button').onclick = () => { send({ t: 'join', code: m.code }); d.remove(); };
    $('#invites').append(d); sfx.play('notify');
  }
});

// ----- налаштування -----
$('#saveSettings').onclick = async () => {
  await api.invoke('settings:set', { curseforgeKey: $('#cfKey').value.trim(), lobbyUrl: $('#lobbyUrl').value.trim(), javaPath: $('#javaPath').value.trim(), autoJava: $('#autoJava').checked, memory: $('#mem').value.trim() || '4G' });
  status('Збережено');
};

// ----- звуки -----
api.invoke('settings:get').then(st => { sfx.enabled = st.sounds !== false; $('#sndOn').checked = sfx.enabled; });
document.addEventListener('click', e => { if (e.target.closest('button:not(:disabled)')) sfx.play('click'); });
$('#sndOn').onchange = e => {
  sfx.enabled = e.target.checked;
  if (sfx.enabled) sfx.play('success');
  api.invoke('settings:set', { sounds: sfx.enabled });
};

api.invoke('app:version').then(v => $('#ver').textContent = 'версія ' + v);

$('#offBtn').onclick = async () => {
  $('#loginErr').textContent = '';
  try { const me = await api.invoke('auth:offline', { name: $('#offName').value.trim() }); await showApp(me); sfx.play('success'); }
  catch (e) { $('#loginErr').textContent = err(e); sfx.play('error'); }
};
$('#offName').addEventListener('keydown', e => { if (e.key === 'Enter') $('#offBtn').click(); });


// ----- оформлення -----
const THEME_DEF = { mode: 'dark', accent: '#3fae6a', radius: 12, font: 14, glow: true };
const SWATCHES = ['#3fae6a', '#4f8cff', '#9b6bff', '#ff5fa2', '#ff9a3c', '#ff5a5a', '#2ec4b6'];
let theme = { ...THEME_DEF };
const cleanTheme = t => ({
  mode: ['dark', 'amoled', 'light'].includes(t.mode) ? t.mode : THEME_DEF.mode,
  accent: /^#[0-9a-f]{6}$/i.test(t.accent) ? t.accent.toLowerCase() : THEME_DEF.accent,
  radius: Math.min(24, Math.max(0, Number(t.radius ?? THEME_DEF.radius) || 0)),
  font: Math.min(18, Math.max(12, Number(t.font) || THEME_DEF.font)),
  glow: t.glow !== false
});
function applyTheme() {
  const r = document.documentElement;
  r.dataset.theme = theme.mode; r.dataset.glow = theme.glow ? 'on' : 'off';
  r.style.setProperty('--acc', theme.accent);
  r.style.setProperty('--r', theme.radius + 'px');
  r.style.setProperty('--fs', theme.font + 'px');
  $('#thMode').value = theme.mode; $('#thAcc').value = theme.accent;
  $('#thRadius').value = theme.radius; $('#thRadiusV').textContent = theme.radius + ' px';
  $('#thFont').value = theme.font; $('#thFontV').textContent = theme.font + ' px';
  $('#thGlow').checked = theme.glow;
  document.querySelectorAll('.sw').forEach(b => b.classList.toggle('on', b.dataset.c === theme.accent));
}
const saveTheme = () => api.invoke('settings:set', { theme });
const setTheme = patch => { theme = cleanTheme({ ...theme, ...patch }); applyTheme(); };
SWATCHES.forEach(c => {
  const b = document.createElement('button');
  b.className = 'sw'; b.dataset.c = c; b.title = c; b.style.background = c;
  b.onclick = () => { setTheme({ accent: c }); saveTheme(); };
  $('#swatches').append(b);
});
$('#thMode').onchange = e => { setTheme({ mode: e.target.value }); saveTheme(); };
$('#thAcc').oninput = e => setTheme({ accent: e.target.value });
$('#thAcc').onchange = saveTheme;
$('#thRadius').oninput = e => setTheme({ radius: e.target.value });
$('#thRadius').onchange = saveTheme;
$('#thFont').oninput = e => setTheme({ font: e.target.value });
$('#thFont').onchange = saveTheme;
$('#thGlow').onchange = e => { setTheme({ glow: e.target.checked }); saveTheme(); };
$('#thReset').onclick = () => { theme = { ...THEME_DEF }; applyTheme(); saveTheme(); };
api.invoke('settings:get').then(st => { theme = cleanTheme(st.theme || {}); applyTheme(); });


// ----- керування збірками -----
const curInst = () => instances.find(i => i.name === $('#inst').value);
function fillMgr() {
  const i = curInst();
  $('#mgName').value = i ? i.name : ''; $('#mgRam').value = (i && i.ram) || ''; $('#mgJvm').value = (i && i.jvm) || '';
}
$('#inst').addEventListener('change', fillMgr);
$('#mgSave').onclick = async () => {
  const i = curInst(); if (!i) return;
  let name = i.name; const to = $('#mgName').value.trim();
  try {
    if (to && to !== i.name) { await api.invoke('instances:rename', { name: i.name, to }); name = to; }
    await api.invoke('instances:update', { name, ram: $('#mgRam').value.trim(), jvm: $('#mgJvm').value });
    await loadInstances(); $('#inst').value = name; fillMgr(); status('Збережено'); sfx.play('success');
  } catch (e) { fail(err(e)); }
};
$('#mgDup').onclick = async () => {
  const i = curInst(); if (!i) return; const to = i.name + ' копія';
  try { await api.invoke('instances:duplicate', { name: i.name, to }); await loadInstances(); $('#inst').value = to; fillMgr(); status('Створено «' + to + '»'); }
  catch (e) { fail(err(e)); }
};
$('#mgDel').onclick = async () => {
  const i = curInst(); if (!i) return;
  if (!confirm(`Видалити збірку «${i.name}» разом зі світами та модами? Це незворотно.`)) return;
  try { await api.invoke('instances:delete', { name: i.name }); await loadInstances(); fillMgr(); status('Видалено'); }
  catch (e) { fail(err(e)); }
};
$('#mgOpen').onclick = () => { const i = curInst(); if (i) api.invoke('instances:openFolder', { name: i.name }); };

})();

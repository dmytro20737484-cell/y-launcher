// Звукові ефекти синтезуються через WebAudio — ніяких аудіофайлів не потрібно.
const sfx = (() => {
  let ctx, enabled = true;
  const ac = () => {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  };
  function tone(freq, start, dur, { type = 'sine', vol = 0.08, slide } = {}) {
    const c = ac(), t = c.currentTime + start;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(slide, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(c.destination);
    o.start(t); o.stop(t + dur + 0.02);
  }
  const S = {
    click:   () => tone(660, 0, 0.06, { type: 'triangle', vol: 0.05, slide: 440 }),
    success: () => { tone(523, 0, 0.12); tone(659, 0.09, 0.12); tone(784, 0.18, 0.24); },
    error:   () => { tone(220, 0, 0.15, { type: 'sawtooth', vol: 0.05 }); tone(165, 0.12, 0.28, { type: 'sawtooth', vol: 0.05 }); },
    notify:  () => { tone(880, 0, 0.1); tone(1175, 0.1, 0.2); },
    launch:  () => tone(330, 0, 0.55, { type: 'triangle', vol: 0.07, slide: 990 })
  };
  return {
    get enabled() { return enabled; },
    set enabled(v) { enabled = !!v; },
    play(n) { if (enabled && S[n]) { try { S[n](); } catch {} } }
  };
})();

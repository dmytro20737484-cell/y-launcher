// Лобі-сервер. Запускається окремо: `npm run lobby` (потрібен публічний хост/VPS для друзів).
const { WebSocketServer } = require('ws');
const crypto = require('crypto');
const HAS = 'https://authserver.ely.by/api/authlib-injector/sessionserver/session/minecraft/hasJoined';
const wss = new WebSocketServer({ port: process.env.PORT || 8787, maxPayload: 4096 });
const online = new Map();   // nick(lower) -> ws
const lobbies = new Map();  // code -> {host, members:[nick], address}

const send = (ws, m) => ws.readyState === 1 && ws.send(JSON.stringify(m));
function broadcast(code) {
  const l = lobbies.get(code); if (!l) return;
  for (const n of l.members) { const w = online.get(n.toLowerCase()); if (w) send(w, { t: 'lobby', code, ...l }); }
}
function leave(ws) {
  const code = ws.lobby; const l = lobbies.get(code); ws.lobby = null;
  if (!l) return;
  l.members = l.members.filter(n => n !== ws.name);
  if (!l.members.length) return void lobbies.delete(code);
  if (l.host === ws.name) l.host = l.members[0];
  broadcast(code);
}
const validAddr = a => typeof a === 'string' && /^[\w.-]{1,253}(:\d{1,5})?$/.test(a);

wss.on('connection', ws => {
  ws.serverId = crypto.randomBytes(16).toString('hex');
  send(ws, { t: 'challenge', serverId: ws.serverId });

  ws.on('message', async raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!ws.name) {
      if (ws.authing || m.t !== 'auth' || !/^[\w.-]{2,32}$/.test(String(m.name))) return;
      ws.authing = true;
      try {
        const r = await fetch(`${HAS}?username=${encodeURIComponent(m.name)}&serverId=${ws.serverId}`);
        if (r.status !== 200) throw new Error('not joined');
      } catch { send(ws, { t: 'error', message: 'Ely.by не підтвердив нік' }); return ws.close(); }
      ws.name = m.name;
      const old = online.get(m.name.toLowerCase()); if (old && old !== ws) old.close();
      online.set(m.name.toLowerCase(), ws);
      return send(ws, { t: 'ready', name: ws.name });
    }
    switch (m.t) {
      case 'create': {
        if (ws.lobby) leave(ws);
        const code = crypto.randomBytes(3).toString('hex').toUpperCase();
        lobbies.set(code, { host: ws.name, members: [ws.name], address: validAddr(m.address) ? m.address : '' });
        ws.lobby = code; broadcast(code); break;
      }
      case 'join': {
        const code = String(m.code || '').toUpperCase(); const l = lobbies.get(code);
        if (!l) return send(ws, { t: 'error', message: 'Лобі не знайдено' });
        if (l.members.length >= 8) return send(ws, { t: 'error', message: 'Лобі заповнене' });
        if (ws.lobby && ws.lobby !== code) leave(ws);
        if (!l.members.includes(ws.name)) l.members.push(ws.name);
        ws.lobby = code; broadcast(code); break;
      }
      case 'invite': {
        if (!lobbies.get(ws.lobby)) return;
        const target = online.get(String(m.to || '').toLowerCase());
        if (!target) return send(ws, { t: 'error', message: `${m.to} не в мережі` });
        send(target, { t: 'invite', code: ws.lobby, from: ws.name });
        break;
      }
      case 'address': {
        const l = lobbies.get(ws.lobby);
        if (l && l.host === ws.name && validAddr(m.address)) { l.address = m.address; broadcast(ws.lobby); }
        break;
      }
      case 'leave': leave(ws); send(ws, { t: 'left' }); break;
    }
  });
  ws.on('close', () => {
    if (!ws.name) return;
    leave(ws);
    if (online.get(ws.name.toLowerCase()) === ws) online.delete(ws.name.toLowerCase());
  });
});
console.log('Lobby server on :' + (process.env.PORT || 8787));

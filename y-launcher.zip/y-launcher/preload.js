const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
  invoke: (ch, ...a) => ipcRenderer.invoke(ch, ...a),
  on: (ch, cb) => ipcRenderer.on(ch, (_e, d) => cb(d))
});
